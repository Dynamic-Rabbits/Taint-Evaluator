#ifndef _TAINT_SOURCE_H
#define _TAINT_SOURCE_H

typedef enum {
    PerByte,
    PerRead,
} taint_range_t;

#endif
