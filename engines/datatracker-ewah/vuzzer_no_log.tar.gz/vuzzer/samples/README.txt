This dir contains sample programs to be used for debugging/testing our pin tools.
